# OOP_Java__Term_project

Version 1 5/11/2024:
[Click me](https://docs.google.com/document/d/1ryp8AVc_aqnJpuUVsEm0vLrMR6mma8sC1tbpRwG8LOU/edit?usp=sharing)

Version 0:
This is the first-hand description of the project: [click me](https://docs.google.com/document/d/1wGJkOUhkQ00wiTCcLalJspbIkLKhLeTaMG2Fdl5slU8/edit?tab=t.0)